
class ShootingRound {
	int numTargets; // number of targets hit (out of five)

	ShootingRound(int numTargets){
		this.numTargets = numTargets;
	}
}

