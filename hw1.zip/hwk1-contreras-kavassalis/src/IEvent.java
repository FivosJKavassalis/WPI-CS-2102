
interface IEvent {

	// takes no additional inputs and returns a double representing an athlete's 
	// score on that event

	public double pointsEarned(); 
}