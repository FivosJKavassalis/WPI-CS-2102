
public class Time {

	private int hour;//military time
	private int minute;

	Time(int hour,int minute){
		this.hour = hour;
		this.minute = minute;
	}
}
