
class MassStartResult extends AbsResult {

	MassStartResult(double time, int position){
		super(time, position);

	}
}