import java.util.LinkedList;

//import java.lang.Math;

interface IBinTree {
	// determines whether element is in the tree
	boolean hasElt(int e);
	// returns number of nodes in the tree; counts duplicate elements as separate items
	int size();
	// returns depth of longest branch in the tree
	int height();

	//-------------------------new code-------------------------
	//Returns whether a tree is empty or not
	public boolean isEmpty();

	//Returns whether a tree is a heap
	public boolean heapTreeCheck();

	//Determines if the root of the tree is the smallest element 
	//by checking if the child's are bigger than the root
	public boolean rootBiggest(int root);

	//Creates a list from the tree
	public LinkedList<Integer> makeList();
}